import React, { useState } from 'react';
import { Project } from '../types';
import { FolderOpen, Plus, Calendar, MoreVertical, Trash2, Edit2, PlayCircle, Film, X, Search } from 'lucide-react';

interface ProjectsListProps {
  projects: Project[];
  onOpenProject: (projectId: string) => void;
  onCreateProject: (project: Omit<Project, 'id' | 'createdAt' | 'scenes'>) => void;
  onEditProject: (id: string, updates: Partial<Project>) => void;
  onDeleteProject: (projectId: string) => void;
}

export const ProjectsList: React.FC<ProjectsListProps> = ({ projects, onOpenProject, onCreateProject, onEditProject, onDeleteProject }) => {
  // Create State
  const [isCreating, setIsCreating] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');

  // Edit State
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDesc, setEditDesc] = useState('');

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;
    
    onCreateProject({
      title: newTitle,
      description: newDesc,
      coverImage: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=2059' // Default generic film cover
    });
    
    setIsCreating(false);
    setNewTitle('');
    setNewDesc('');
  };

  const startEditing = (e: React.MouseEvent, project: Project) => {
      e.preventDefault();
      e.stopPropagation();
      setEditingProject(project);
      setEditTitle(project.title);
      setEditDesc(project.description);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (editingProject) {
          onEditProject(editingProject.id, {
              title: editTitle,
              description: editDesc
          });
          setEditingProject(null);
      }
  };

  return (
    <div className="w-full animate-fade-in space-y-10 pb-20">
      
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-cine-800">
        <div>
           <h2 className="text-4xl font-bold text-white tracking-tight mb-2">Dashboard</h2>
           <p className="text-gray-400">Manage your active productions and concept boards.</p>
        </div>
        
        <div className="flex gap-4 w-full md:w-auto">
            {/* Search Placeholder */}
            <div className="relative flex-grow md:flex-grow-0">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input 
                    type="text" 
                    placeholder="Search projects..." 
                    className="w-full md:w-64 bg-cine-800 border border-cine-700 rounded-lg py-2.5 pl-9 pr-4 text-sm text-white focus:ring-1 focus:ring-cine-accent outline-none"
                />
            </div>

            <button 
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-2 bg-cine-accent hover:bg-yellow-400 text-cine-900 px-6 py-2.5 rounded-lg font-bold transition-all shadow-lg shadow-amber-900/20 hover:shadow-amber-900/40 hover:-translate-y-0.5 active:translate-y-0"
            >
              <Plus className="w-5 h-5" /> New Project
            </button>
        </div>
      </div>

      {/* Projects Grid */}
      {projects.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 border-2 border-dashed border-cine-800 rounded-2xl bg-cine-900/30">
          <div className="p-4 bg-cine-800 rounded-full mb-6">
             <Film className="w-12 h-12 text-cine-600" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-2">No projects yet</h3>
          <p className="text-gray-500 mb-8 max-w-sm text-center">Start your previsualization journey by creating your first project container.</p>
          <button 
              onClick={() => setIsCreating(true)}
              className="flex items-center gap-2 text-cine-accent hover:text-white font-medium transition-colors border border-cine-700 hover:border-cine-500 px-6 py-2 rounded-lg"
          >
              <Plus className="w-4 h-4" /> Create First Project
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {projects.map(project => (
            <div 
                key={project.id} 
                className="group bg-cine-800 rounded-2xl overflow-hidden border border-cine-700 hover:border-cine-500 transition-all hover:shadow-2xl hover:shadow-black/50 flex flex-col h-full cursor-pointer relative"
                onClick={() => onOpenProject(project.id)}
            >
              {/* Cover Image */}
              <div className="aspect-video overflow-hidden relative bg-black">
                <img 
                  src={project.coverImage} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80 group-hover:opacity-100" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-cine-800 via-transparent to-transparent opacity-80" />
                
                {/* Overlay Badge */}
                <div className="absolute top-3 right-3">
                   <span className="px-2 py-1 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider rounded border border-white/10">
                       {project.scenes.length > 0 ? 'In Production' : 'Concept'}
                   </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 flex-grow flex flex-col relative z-10 -mt-6">
                <div className="bg-cine-800 pt-4 rounded-t-2xl">
                    <div className="flex justify-between items-start mb-2">
                        <h3 className="text-xl font-bold text-white line-clamp-1 group-hover:text-cine-accent transition-colors pr-2">{project.title}</h3>
                         <button 
                            onClick={(e) => startEditing(e, project)}
                            className="text-gray-500 hover:text-white transition-colors p-1"
                        >
                            <MoreVertical className="w-4 h-4" />
                        </button>
                    </div>
                    
                    <p className="text-sm text-gray-400 line-clamp-3 mb-6 flex-grow leading-relaxed">{project.description || "No description added."}</p>
                    
                    <div className="flex items-center justify-between text-xs text-gray-500 border-t border-cine-700 pt-4 mt-auto">
                        <div className="flex items-center gap-4">
                            <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" /> {new Date(project.createdAt).toLocaleDateString()}</span>
                            <span className="flex items-center gap-1.5"><Film className="w-3.5 h-3.5" /> {project.scenes.length}</span>
                        </div>
                        <button 
                            onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                onDeleteProject(project.id);
                            }}
                            className="text-gray-600 hover:text-red-400 transition-colors"
                            title="Delete Project"
                        >
                            <Trash2 className="w-4 h-4" />
                        </button>
                    </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Modal */}
      {isCreating && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-cine-800 border border-cine-700 rounded-2xl p-8 w-full max-w-lg shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <h3 className="text-2xl font-bold text-white mb-6">Create New Project</h3>
            <form onSubmit={handleCreateSubmit} className="space-y-6">
              <div>
                <label className="text-sm text-gray-400 font-medium block mb-2">Project Title</label>
                <input 
                  autoFocus
                  type="text" 
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-cine-900 border border-cine-700 rounded-xl p-3 text-white focus:ring-1 focus:ring-cine-accent focus:border-cine-accent outline-none transition-all placeholder-gray-600"
                  placeholder="e.g. The Maltese Falcon Remake"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 font-medium block mb-2">Logline / Description</label>
                <textarea 
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-cine-900 border border-cine-700 rounded-xl p-3 text-white focus:ring-1 focus:ring-cine-accent focus:border-cine-accent outline-none resize-none h-32 transition-all placeholder-gray-600"
                  placeholder="A cool detective story set in 2049..."
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsCreating(false)}
                  className="px-5 py-2.5 text-gray-400 hover:text-white transition-colors font-medium"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={!newTitle}
                  className="px-6 py-2.5 bg-cine-accent text-cine-900 font-bold rounded-xl hover:bg-yellow-400 disabled:opacity-50 transition-all shadow-lg hover:shadow-amber-500/20"
                >
                  Create Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingProject && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-cine-800 border border-cine-700 rounded-2xl p-8 w-full max-w-lg shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-white">Edit Project</h3>
                <button onClick={() => setEditingProject(null)} className="text-gray-400 hover:text-white p-1 bg-cine-900 rounded-full"><X className="w-5 h-5"/></button>
            </div>
            <form onSubmit={handleEditSubmit} className="space-y-6">
              <div>
                <label className="text-sm text-gray-400 font-medium block mb-2">Project Title</label>
                <input 
                  autoFocus
                  type="text" 
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full bg-cine-900 border border-cine-700 rounded-xl p-3 text-white focus:ring-1 focus:ring-cine-accent focus:border-cine-accent outline-none transition-all"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 font-medium block mb-2">Description</label>
                <textarea 
                  value={editDesc}
                  onChange={(e) => setEditDesc(e.target.value)}
                  className="w-full bg-cine-900 border border-cine-700 rounded-xl p-3 text-white focus:ring-1 focus:ring-cine-accent focus:border-cine-accent outline-none resize-none h-32 transition-all"
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setEditingProject(null)}
                  className="px-5 py-2.5 text-gray-400 hover:text-white transition-colors font-medium"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={!editTitle}
                  className="px-6 py-2.5 bg-cine-accent text-cine-900 font-bold rounded-xl hover:bg-yellow-400 disabled:opacity-50 transition-all shadow-lg hover:shadow-amber-500/20"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
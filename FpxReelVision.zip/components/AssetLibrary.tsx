import React, { useState, useRef } from 'react';
import { Asset } from '../types';
import { generateAssetSketch } from '../services/gemini';
import { Box, Sparkles, Loader2, Upload, Trash2, Maximize2, MapPin, Car, Briefcase, Camera } from 'lucide-react';

interface AssetLibraryProps {
  assets: Asset[];
  setAssets: React.Dispatch<React.SetStateAction<Asset[]>>;
}

export const AssetLibrary: React.FC<AssetLibraryProps> = ({ assets, setAssets }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Form State
  const [name, setName] = useState('');
  const [type, setType] = useState<'Location' | 'Vehicle' | 'Prop' | 'Equipment'>('Location');
  const [description, setDescription] = useState('');
  const [style, setStyle] = useState('Storyboard Sketch');
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!name) return;
    
    setIsGenerating(true);
    try {
      const sketchUrl = await generateAssetSketch(name, type, referenceImage, description, style);
      
      const newAsset: Asset = {
        id: Date.now().toString(),
        name: name,
        type: type,
        description: description,
        reference_image: referenceImage,
        sketch_image: sketchUrl,
        style: style,
        created_at: new Date().toISOString()
      };

      setAssets(prev => [...prev, newAsset]);
      
      // Reset critical form fields
      setName('');
      setDescription('');
    } catch (error: any) {
      alert(error.message || "Failed to generate asset. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDelete = (id: string) => {
    setAssets(prev => prev.filter(a => a.id !== id));
  };

  const getTypeIcon = (assetType: string) => {
      switch(assetType) {
          case 'Location': return <MapPin className="w-4 h-4" />;
          case 'Vehicle': return <Car className="w-4 h-4" />;
          case 'Prop': return <Briefcase className="w-4 h-4" />;
          case 'Equipment': return <Camera className="w-4 h-4" />;
          default: return <Box className="w-4 h-4" />;
      }
  };

  return (
    <div className="w-full max-w-6xl mx-auto animate-fade-in space-y-8">
      
      {/* Creation Form */}
      <div className="bg-cine-800 rounded-xl p-6 border border-cine-700 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <Box className="w-6 h-6 text-cine-accent" />
          Create Production Asset
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Asset Name</label>
                    <input 
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Interrogation Room"
                        className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">Type</label>
                    <select 
                        value={type}
                        onChange={(e) => setType(e.target.value as any)}
                        className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none"
                    >
                        <option value="Location">Location / Environment</option>
                        <option value="Vehicle">Vehicle</option>
                        <option value="Prop">Key Prop</option>
                        <option value="Equipment">Equipment</option>
                    </select>
                </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Visual Description</label>
              <textarea 
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the asset. For locations, describe lighting and architecture. For vehicles, model and color."
                rows={3}
                className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Art Style</label>
              <select 
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none"
              >
                <option value="Storyboard Sketch">Storyboard Sketch</option>
                <option value="Realistic">Realistic</option>
                <option value="Anime">Anime</option>
                <option value="Noir">Film Noir</option>
                <option value="Architectural Blueprint">Architectural Blueprint</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-400 mb-1">Reference Image (Optional)</label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-48 border-2 border-dashed border-cine-600 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-cine-accent hover:bg-cine-900/50 transition-all relative overflow-hidden group"
            >
               {referenceImage ? (
                 <>
                   <img src={referenceImage} alt="Reference" className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" />
                   <div className="absolute inset-0 flex items-center justify-center">
                      <span className="bg-black/70 text-white text-xs px-2 py-1 rounded">Click to change</span>
                   </div>
                 </>
               ) : (
                 <>
                   <Upload className="w-8 h-8 text-cine-500 mb-2" />
                   <span className="text-sm text-cine-400">Upload Reference Image</span>
                 </>
               )}
               <input 
                 type="file" 
                 ref={fileInputRef} 
                 onChange={handleImageUpload} 
                 accept="image/*" 
                 className="hidden" 
               />
            </div>
            
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !name}
              className={`w-full py-3 rounded-lg font-semibold text-white flex items-center justify-center gap-2 transition-all mt-auto
                ${isGenerating || !name ? 'bg-cine-700 cursor-not-allowed' : 'bg-cine-accent hover:bg-yellow-500 shadow-lg shadow-amber-900/20'}
              `}
            >
              {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              {isGenerating ? 'Designing Asset...' : 'Generate Asset'}
            </button>
          </div>
        </div>
      </div>

      {/* Library Grid */}
      <div>
        <h3 className="text-lg font-bold text-white mb-4">Assets & Locations</h3>
        {assets.length === 0 ? (
          <div className="text-center py-12 text-gray-500 border border-cine-800 rounded-xl bg-cine-900/30">
            <Box className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p>No assets created yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {assets.map(asset => (
              <div key={asset.id} className="bg-cine-900 border border-cine-700 rounded-xl overflow-hidden group relative hover:border-cine-600 transition-colors">
                <div className="aspect-[4/3] relative bg-black">
                  <img src={asset.sketch_image} alt={asset.name} className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2">
                     <span className="px-2 py-1 bg-black/70 backdrop-blur-sm rounded text-[10px] text-white font-bold uppercase border border-white/10 flex items-center gap-1">
                        {getTypeIcon(asset.type)} {asset.type}
                     </span>
                  </div>
                  <button 
                    onClick={() => window.open(asset.sketch_image, '_blank')}
                    className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="p-4 flex items-center justify-between border-t border-cine-800">
                  <div>
                    <h4 className="font-bold text-white">{asset.name}</h4>
                    <p className="text-xs text-gray-500 line-clamp-1">{asset.description}</p>
                  </div>
                  <button 
                    onClick={() => handleDelete(asset.id)}
                    className="text-gray-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
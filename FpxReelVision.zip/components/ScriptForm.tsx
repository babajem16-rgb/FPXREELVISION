import React, { useState, useRef } from 'react';
import { Film, Sparkles, Loader2, Globe, Upload, FileUp, X, FileText as FileIcon } from 'lucide-react';
import { AppState } from '../types';

interface ScriptFormProps {
  onAnalyze: (script: string) => void;
  appState: AppState;
}

const DEFAULT_SCRIPT = `EXT. ALLEYWAY - NIGHT

Rain slicks the cobblestones. NEON LIGHTS reflect in the puddles.

DETECTIVE MILLER (40s, trench coat) stumbles out of a back door, clutching his side. He's been shot.

He leans against the brick wall, breathing heavy. He looks at the blood on his hand.

MILLER
(gritty whisper)
Not like this...

A shadow lengthens down the alley. Miller looks up. A SILHOUETTE stands at the alley mouth, holding a smoking gun.`;

export const ScriptForm: React.FC<ScriptFormProps> = ({ onAnalyze, appState }) => {
  const [script, setScript] = useState(DEFAULT_SCRIPT);
  const [fileName, setFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (script.trim()) {
      onAnalyze(script);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setScript(text);
    };
    
    reader.onerror = () => {
      alert("Failed to read file");
      setFileName(null);
    };

    reader.readAsText(file);
  };

  const handleClearFile = () => {
    setScript(DEFAULT_SCRIPT);
    setFileName(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = '';
    }
  };

  const isLoading = appState === AppState.ANALYZING;

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-cine-800 rounded-xl shadow-2xl border border-cine-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3 text-cine-text">
            <Film className="w-6 h-6 text-cine-accent" />
            <div>
                <h2 className="text-xl font-bold tracking-tight">Script Input</h2>
                <p className="text-xs text-gray-400">Paste text or upload a file to parse scenes</p>
            </div>
        </div>
        
        <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-cine-900 rounded-full text-xs text-gray-400 border border-cine-700">
                <Globe className="w-3 h-3" />
                <span>Multi-language Support</span>
            </div>
            
            <button 
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 px-4 py-2 bg-cine-700 hover:bg-cine-600 text-white text-sm font-medium rounded-lg transition-colors border border-cine-600"
            >
                <Upload className="w-4 h-4" />
                Upload Script
            </button>
            <input 
                ref={fileInputRef}
                type="file"
                accept=".txt,.fountain,.md,.trelby"
                onChange={handleFileUpload}
                className="hidden"
            />
        </div>
      </div>
      
      {fileName && (
          <div className="mb-4 bg-cine-900/50 border border-cine-700 rounded-lg p-3 flex items-center justify-between animate-fade-in">
              <div className="flex items-center gap-3">
                  <div className="p-2 bg-cine-800 rounded text-cine-accent">
                      <FileIcon className="w-4 h-4" />
                  </div>
                  <div>
                      <p className="text-sm text-white font-medium">{fileName}</p>
                      <p className="text-xs text-gray-500">File loaded successfully</p>
                  </div>
              </div>
              <button onClick={handleClearFile} className="p-1 hover:bg-cine-700 rounded text-gray-400 hover:text-white transition-colors">
                  <X className="w-4 h-4" />
              </button>
          </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative group">
          <textarea
            value={script}
            onChange={(e) => setScript(e.target.value)}
            className="w-full h-80 p-5 bg-cine-900 text-cine-text border border-cine-700 rounded-xl focus:ring-2 focus:ring-cine-accent focus:border-transparent font-mono text-sm leading-relaxed resize-y outline-none transition-all shadow-inner"
            placeholder="Paste your scene script here or upload a file..."
            disabled={isLoading}
          />
          {!script.trim() && !fileName && (
             <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none opacity-40">
                 <FileUp className="w-12 h-12 text-gray-500 mb-2" />
                 <p className="text-sm text-gray-400">Drag and drop or paste script here</p>
             </div>
          )}
          <div className="absolute top-3 right-3 text-xs text-cine-500 pointer-events-none bg-cine-950/80 backdrop-blur px-2 py-1 rounded border border-cine-800">
            Fountain/Screenplay format
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={isLoading || !script.trim()}
            className={`
              flex items-center gap-2 px-8 py-3.5 rounded-xl font-bold text-white transition-all transform
              ${isLoading 
                ? 'bg-cine-700 cursor-not-allowed opacity-75' 
                : 'bg-cine-accent hover:bg-yellow-500 hover:scale-[1.02] shadow-xl shadow-amber-900/20'}
            `}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Parsing Script & Generating Shots...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>Analyze & Visualize Scene</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

import React, { useState } from 'react';
import { Shot, Character, Asset } from '../types';
import { Camera, Zap, Image as ImageIcon, Loader2, Maximize2, FilePenLine, Link as LinkIcon, RefreshCw, X, Check, Settings2, MapPin, Clock, Eye } from 'lucide-react';

interface ShotCardProps {
  shot: Shot;
  characters?: Character[];
  assets?: Asset[];
  onGenerateImage: (id: number, prompt: string) => void;
  onUpdateShot?: (id: number, updates: Partial<Shot>) => void;
  onUpdateNotes: (id: number, notes: string) => void;
}

export const ShotCard: React.FC<ShotCardProps> = ({ shot, characters = [], assets = [], onGenerateImage, onUpdateShot, onUpdateNotes }) => {
  const [isEditing, setIsEditing] = useState(false);
  
  // Local state for editing fields before saving/regenerating
  const [editData, setEditData] = useState({
    shotType: shot.shotType,
    cameraAngle: shot.cameraAngle,
    framing: shot.framing,
    lightingMood: shot.lightingMood,
    sketchPrompt: shot.sketchPrompt,
    estimatedDuration: shot.estimatedDuration || 5,
    lens: shot.lens || "35mm"
  });

  const handleEditChange = (field: string, value: string | number) => {
    setEditData(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveAndRegenerate = () => {
    if (onUpdateShot) {
      onUpdateShot(shot.id, editData);
    }
    
    // Construct a forceful prompt that includes the technical details
    // ensuring the AI respects the dropdown changes
    const compositePrompt = `
      Technique: ${editData.shotType} shot, ${editData.cameraAngle} angle, ${editData.framing}. 
      Lens: ${editData.lens}.
      Lighting: ${editData.lightingMood}. 
      Action: ${editData.sketchPrompt}
    `.trim();

    onGenerateImage(shot.id, compositePrompt);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    // Revert local state to props
    setEditData({
      shotType: shot.shotType,
      cameraAngle: shot.cameraAngle,
      framing: shot.framing,
      lightingMood: shot.lightingMood,
      sketchPrompt: shot.sketchPrompt,
      estimatedDuration: shot.estimatedDuration || 5,
      lens: shot.lens || "35mm"
    });
    setIsEditing(false);
  };

  // Detect if any characters or assets are mentioned in the prompt
  const currentPrompt = isEditing ? editData.sketchPrompt : shot.sketchPrompt;
  const promptLower = currentPrompt.toLowerCase();

  const linkedCharacters = characters.filter(c => {
    const nameParts = c.character_name.toLowerCase().split(/\s+/);
    return promptLower.includes(c.character_name.toLowerCase()) || 
           nameParts.some(part => part.length >= 2 && promptLower.includes(part));
  });

  const linkedAssets = assets.filter(a => {
      const nameParts = a.name.toLowerCase().split(/\s+/);
      return promptLower.includes(a.name.toLowerCase()) ||
             nameParts.some(part => part.length >= 3 && promptLower.includes(part));
  });

  return (
    <div className="shot-card bg-cine-800 rounded-xl overflow-hidden border border-cine-700 hover:border-cine-600 transition-all flex flex-col md:flex-row group break-inside-avoid shadow-lg">
      
      {/* Visual / Image Section */}
      <div className="shot-card-img-container md:w-1/3 bg-black relative min-h-[240px] md:min-h-full flex items-center justify-center border-b md:border-b-0 md:border-r border-cine-700 print:border-r-0">
        {shot.imageUrl ? (
          <>
            <img 
              src={shot.imageUrl} 
              alt={`Shot ${shot.shotNumber}`} 
              className="w-full h-full object-cover transition-opacity duration-300"
            />
            {shot.isGeneratingImage && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-sm z-10">
                 <Loader2 className="w-8 h-8 animate-spin text-cine-accent" />
              </div>
            )}
            
            <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2 pdf-hide">
               <button 
                onClick={() => setIsEditing(true)}
                className="p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-md backdrop-blur-sm"
                title="Edit & Regenerate"
               >
                 <Settings2 className="w-4 h-4" />
               </button>
               <button 
                onClick={() => window.open(shot.imageUrl, '_blank')}
                className="p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-md backdrop-blur-sm"
                title="View Fullscreen"
               >
                 <Maximize2 className="w-4 h-4" />
               </button>
            </div>
          </>
        ) : (
          <div className="text-center p-6 flex flex-col items-center">
            {shot.isGeneratingImage ? (
              <div className="flex flex-col items-center text-cine-accent animate-pulse">
                <Loader2 className="w-10 h-10 animate-spin mb-3" />
                <span className="text-xs font-mono uppercase tracking-widest">Rendering Sketch...</span>
              </div>
            ) : (
              <>
                <ImageIcon className="w-12 h-12 text-cine-700 mb-3" />
                <button
                  onClick={() => onGenerateImage(shot.id, shot.sketchPrompt)}
                  className="px-4 py-2 bg-cine-700 hover:bg-cine-600 text-white text-xs font-semibold rounded-full transition-colors flex items-center gap-2 relative pdf-hide"
                >
                  <Zap className="w-3 h-3" />
                  Generate Storyboard
                </button>
              </>
            )}
          </div>
        )}

        {/* Smart Link Badges (Visible in both modes if matches found) */}
        {!shot.isGeneratingImage && (linkedCharacters.length > 0 || linkedAssets.length > 0) && (
            <div className="absolute bottom-3 left-3 flex flex-wrap gap-1 max-w-[85%] pdf-hide">
                {/* Character Badges */}
                {linkedCharacters.map(char => (
                    <span key={char.id} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/70 border border-cine-accent/50 text-[10px] text-cine-accent font-medium backdrop-blur-md shadow-sm">
                        <LinkIcon className="w-3 h-3" />
                        {char.character_name}
                    </span>
                ))}
                {/* Asset Badges */}
                {linkedAssets.map(asset => (
                    <span key={asset.id} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/70 border border-blue-400/50 text-[10px] text-blue-400 font-medium backdrop-blur-md shadow-sm">
                        <MapPin className="w-3 h-3" />
                        {asset.name}
                    </span>
                ))}
            </div>
        )}

        <div className="absolute top-3 left-3 flex gap-2 z-20">
            <div className="bg-cine-accent text-cine-900 font-bold px-2 py-1 rounded text-sm shadow-md">
                #{shot.shotNumber}
            </div>
            {/* Duration Badge */}
            <div className="bg-black/60 backdrop-blur text-white px-2 py-1 rounded text-xs font-mono border border-white/10 flex items-center gap-1 shadow-md">
               <Clock className="w-3 h-3" /> {shot.estimatedDuration}s
            </div>
        </div>
      </div>

      {/* Details Section */}
      <div className="shot-card-content md:w-2/3 p-6 flex flex-col justify-between relative">
        
        {isEditing ? (
            /* EDIT MODE */
            <div className="space-y-4 animate-fade-in pdf-hide">
                <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                        <Settings2 className="w-4 h-4 text-cine-accent" /> Adjust Shot Details
                    </h3>
                    <div className="flex items-center gap-2">
                        <button onClick={handleCancelEdit} className="p-1 hover:text-white text-gray-400"><X className="w-5 h-5"/></button>
                    </div>
                </div>

                <div className="grid grid-cols-4 gap-2">
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase">Type</label>
                        <select 
                            value={editData.shotType}
                            onChange={(e) => handleEditChange('shotType', e.target.value)}
                            className="w-full bg-cine-900 border border-cine-700 rounded p-1 text-xs text-white"
                        >
                            <option>Static</option><option>Handheld</option><option>Dolly Zoom</option><option>Tracking</option><option>Crane</option><option>Drone</option><option>Steadicam</option><option>Pan</option><option>Tilt</option>
                        </select>
                    </div>
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase">Angle</label>
                        <select 
                            value={editData.cameraAngle}
                            onChange={(e) => handleEditChange('cameraAngle', e.target.value)}
                            className="w-full bg-cine-900 border border-cine-700 rounded p-1 text-xs text-white"
                        >
                            <option>Eye Level</option><option>Low Angle</option><option>High Angle</option><option>Dutch Angle</option><option>Over the Shoulder</option><option>Bird's Eye</option><option>Worm's Eye</option>
                        </select>
                    </div>
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase">Lens</label>
                        <select 
                            value={editData.lens}
                            onChange={(e) => handleEditChange('lens', e.target.value)}
                            className="w-full bg-cine-900 border border-cine-700 rounded p-1 text-xs text-white"
                        >
                             <option>16mm</option><option>24mm</option><option>35mm</option><option>50mm</option><option>85mm</option><option>100mm</option><option>200mm</option>
                        </select>
                    </div>
                    <div>
                        <label className="text-[10px] text-gray-500 uppercase">Duration (s)</label>
                        <input 
                            type="number"
                            value={editData.estimatedDuration}
                            onChange={(e) => handleEditChange('estimatedDuration', parseInt(e.target.value))}
                            className="w-full bg-cine-900 border border-cine-700 rounded p-1 text-xs text-white"
                        />
                    </div>
                </div>

                <div>
                    <label className="text-[10px] text-gray-500 uppercase">Framing</label>
                    <select 
                        value={editData.framing}
                        onChange={(e) => handleEditChange('framing', e.target.value)}
                        className="w-full bg-cine-900 border border-cine-700 rounded p-1 text-xs text-white"
                    >
                            <option>Extreme Close Up (ECU)</option><option>Close Up (CU)</option><option>Medium Shot (MS)</option><option>Medium Wide (MWS)</option><option>Wide Shot (WS)</option><option>Extreme Wide (EWS)</option>
                    </select>
                </div>

                <div>
                    <label className="text-[10px] text-gray-500 uppercase">Lighting Mood</label>
                    <input 
                        type="text" 
                        value={editData.lightingMood}
                        onChange={(e) => handleEditChange('lightingMood', e.target.value)}
                        className="w-full bg-cine-900 border border-cine-700 rounded p-2 text-xs text-white focus:ring-1 focus:ring-cine-accent outline-none" 
                    />
                </div>

                <div>
                    <label className="text-[10px] text-gray-500 uppercase">Visual Prompt</label>
                    <textarea 
                        value={editData.sketchPrompt}
                        onChange={(e) => handleEditChange('sketchPrompt', e.target.value)}
                        className="w-full bg-cine-900 border border-cine-700 rounded p-2 text-xs text-white focus:ring-1 focus:ring-cine-accent outline-none h-20 resize-none"
                    />
                </div>

                <div className="flex gap-2 pt-2">
                    <button 
                        onClick={handleSaveAndRegenerate}
                        className="flex-1 bg-cine-accent hover:bg-yellow-500 text-cine-900 font-bold py-2 rounded text-xs flex items-center justify-center gap-2 transition-colors"
                    >
                        <RefreshCw className="w-3 h-3" /> Regenerate Sketch
                    </button>
                    <button 
                        onClick={handleCancelEdit}
                        className="px-4 py-2 bg-cine-700 hover:bg-cine-600 text-white rounded text-xs font-medium"
                    >
                        Cancel
                    </button>
                </div>
            </div>
        ) : (
            /* VIEW MODE */
            <div className="h-full flex flex-col justify-between">
                <div>
                    <div className="shot-card-meta flex flex-wrap gap-2 mb-4">
                        <span className="px-2 py-1 bg-cine-900 border border-cine-700 rounded text-xs text-cine-300 font-mono">
                        {shot.shotType}
                        </span>
                        <span className="px-2 py-1 bg-cine-900 border border-cine-700 rounded text-xs text-cine-300 font-mono">
                        {shot.cameraAngle}
                        </span>
                        <span className="px-2 py-1 bg-cine-900 border border-cine-700 rounded text-xs text-cine-300 font-mono">
                        {shot.framing}
                        </span>
                        {/* New Lens Badge */}
                        <span className="px-2 py-1 bg-cine-900 border border-cine-700 rounded text-xs text-cine-accent font-mono flex items-center gap-1">
                            <Eye className="w-3 h-3" /> {shot.lens || "N/A"}
                        </span>
                        
                        {/* Edit Button for Shot Parameters */}
                        <button 
                            onClick={() => setIsEditing(true)}
                            className="px-2 py-1 bg-cine-900/50 hover:bg-cine-800 border border-cine-700 border-dashed rounded text-xs text-gray-500 hover:text-cine-accent transition-colors ml-auto pdf-hide"
                            title="Edit Parameters"
                        >
                            <Settings2 className="w-3 h-3" />
                        </button>
                    </div>

                    <h3 className="shot-card-action text-lg font-medium text-white mb-2 leading-tight">
                        {shot.action}
                    </h3>
                    
                    <div className="shot-card-details mt-4 space-y-3">
                        <div className="flex items-start gap-2">
                            <div className="mt-1 min-w-[16px]"><Zap className="w-4 h-4 text-cine-accent" /></div>
                            <p className="text-sm text-gray-400">
                            <span className="text-gray-300 font-semibold">Lighting:</span> {shot.lightingMood}
                            </p>
                        </div>
                        
                        {/* SKETCH PROMPT - HIDDEN IN PDF */}
                        <div className="flex items-start gap-2 pdf-hide">
                            <div className="mt-1 min-w-[16px]"><Camera className="w-4 h-4 text-cine-accent" /></div>
                            <p className="text-sm text-gray-400 italic">
                            <span className="text-gray-300 font-semibold not-italic">Sketch Prompt:</span> "{shot.sketchPrompt}"
                            </p>
                        </div>
                    </div>
                </div>

                {/* User Notes Section */}
                <div className="shot-card-notes mt-6 pt-4 border-t border-cine-700">
                    <div className="flex items-center gap-2 mb-2 text-cine-300">
                        <FilePenLine className="w-4 h-4" />
                        <span className="text-xs font-semibold uppercase tracking-wider">Director's Notes</span>
                    </div>
                    
                    {/* Display Textarea normally */}
                    <textarea 
                        className="w-full bg-cine-900/50 border border-cine-700 rounded-lg p-3 text-sm text-gray-300 focus:ring-1 focus:ring-cine-accent focus:border-cine-accent outline-none resize-none transition-all placeholder-gray-600 pdf-hide"
                        rows={2}
                        placeholder="Add logistics, lens details, or specific direction here..."
                        value={shot.userNotes || ''}
                        onChange={(e) => onUpdateNotes(shot.id, e.target.value)}
                    />
                    
                    {/* Display Div only during PDF generation to ensure text is captured fully */}
                    <div className="pdf-show w-full bg-transparent text-sm text-gray-300 whitespace-pre-wrap">
                        {shot.userNotes || 'No notes added.'}
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { AnalysisResult, Shot, Character, Scene, Asset } from '../types';
import { SceneInfo } from './SceneInfo';
import { ShotCard } from './ShotCard';
import { Download, Code, List, Palette, FileText, Loader2, ArrowLeft, Save, Sparkles, Layers, CheckSquare, Square, Table, Clock } from 'lucide-react';
import { generateStoryboardImage } from '../services/gemini';

// html2pdf is loaded globally via script tag in index.html to avoid ESM bundling issues
declare var html2pdf: any;

interface DashboardProps {
  scene: Scene; 
  characters: Character[];
  assets: Asset[];
  onBack: () => void;
  onUpdateScene: (updatedScene: Scene) => void;
}

const VISUAL_STYLES = [
  "Cinematic Noir",
  "Realistic",
  "Anime",
  "Sketch",
  "Watercolor"
];

export const Dashboard: React.FC<DashboardProps> = ({ scene, characters, assets, onBack, onUpdateScene }) => {
  const [shots, setShots] = useState<Shot[]>(scene.shots);
  const [activeTab, setActiveTab] = useState<'visual' | 'json'>('visual');
  const [visualStyle, setVisualStyle] = useState<string>("Cinematic Noir");
  const [isDownloadingPdf, setIsDownloadingPdf] = useState(false);
  const [isBatchGenerating, setIsBatchGenerating] = useState(false);
  const [includeWatermark, setIncludeWatermark] = useState(true);

  // Sync internal state if prop changes (rare in this flow but good practice)
  useEffect(() => {
    setShots(scene.shots);
  }, [scene.shots]);

  // Helper to persist changes
  const persistChanges = (newShots: Shot[]) => {
    setShots(newShots);
    onUpdateScene({
        ...scene,
        shots: newShots
    });
  };

  // Calculate Total Runtime
  const totalRuntime = shots.reduce((acc, shot) => acc + (shot.estimatedDuration || 0), 0);
  const formatRuntime = (seconds: number) => {
      const m = Math.floor(seconds / 60);
      const s = seconds % 60;
      return `${m}m ${s}s`;
  };

  const handleGenerateImage = async (id: number, prompt: string) => {
    // Optimistic update using functional state to ensure safety during batch processing
    setShots(prev => prev.map(s => s.id === id ? { ...s, isGeneratingImage: true } : s));

    try {
      // Pass the library characters and assets to the generator to check for matches
      const imageUrl = await generateStoryboardImage(prompt, visualStyle, characters, assets);
      
      setShots(prev => {
          const newShots = prev.map(s => s.id === id ? { ...s, imageUrl, isGeneratingImage: false } : s);
          // Sync with parent inside the callback to ensure we have the latest state
          onUpdateScene({ ...scene, shots: newShots });
          return newShots;
      });
    } catch (error: any) {
      console.error(error);
      setShots(prev => prev.map(s => s.id === id ? { ...s, isGeneratingImage: false } : s));
      // Only show alert if we are not in batch mode to avoid spamming the user
      if (!isBatchGenerating) {
        alert(error.message || "Failed to generate image. Please try again.");
      }
    }
  };

  const handleBatchGenerate = async () => {
    if (isBatchGenerating) return;
    setIsBatchGenerating(true);

    // Filter shots that don't have images yet to avoid overwriting existing work
    // and to save processing time/credits.
    const shotsToProcess = shots.filter(s => !s.imageUrl);
    
    // Iterate sequentially to prevent rate limiting and ensure stable state updates ("one by one")
    for (const shot of shotsToProcess) {
        await handleGenerateImage(shot.id, shot.sketchPrompt);
    }

    setIsBatchGenerating(false);
  };

  // Allow updating any field of a shot (for editing parameters before regeneration)
  const handleUpdateShot = (id: number, updates: Partial<Shot>) => {
    const updatedShots = shots.map(s => s.id === id ? { ...s, ...updates } : s);
    persistChanges(updatedShots);
  };

  const handleUpdateNotes = (id: number, notes: string) => {
      const updatedShots = shots.map(s => s.id === id ? { ...s, userNotes: notes } : s);
      persistChanges(updatedShots);
  };

  const handleExportJson = () => {
    const jsonString = JSON.stringify({ summary: scene.summary, shots }, null, 2);
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${scene.title.replace(/\s+/g, '_')}_previz.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExportCsv = () => {
    const headers = ["Shot #", "Type", "Angle", "Framing", "Lens", "Duration(s)", "Action", "Lighting", "Notes"];
    const rows = shots.map(s => [
        s.shotNumber,
        s.shotType,
        s.cameraAngle,
        s.framing,
        s.lens || "",
        s.estimatedDuration || 0,
        `"${s.action.replace(/"/g, '""')}"`, // Escape quotes for CSV
        `"${s.lightingMood.replace(/"/g, '""')}"`,
        `"${(s.userNotes || "").replace(/"/g, '""')}"`
    ]);

    const csvContent = [
        headers.join(","),
        ...rows.map(r => r.join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${scene.title.replace(/\s+/g, '_')}_shotlist.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadPDF = async () => {
    setIsDownloadingPdf(true);
    const element = document.getElementById('storyboard-content');
    
    // Check if element exists
    if (!element) {
        console.error("Storyboard content element not found");
        setIsDownloadingPdf(false);
        return;
    }

    // Advanced options for better layout control
    const opt = {
      margin: [10, 10, 10, 10], // top, left, bottom, right in mm
      filename: `${scene.title}_storyboard.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      // Force page breaks after specific elements using CSS class
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] },
      html2canvas: { 
          scale: 2, 
          useCORS: true, 
          letterRendering: true,
          // Manipulate the DOM clone to switch textareas for divs for better printing
          onclone: (clonedDoc: Document) => {
             const content = clonedDoc.getElementById('storyboard-content');
             if (content) {
                 content.classList.add('pdf-mode');
             }
          }
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    try {
      // Create the PDF worker
      const worker = html2pdf().set(opt).from(element).toPdf();
      
      // If watermark is enabled, access the raw PDF object before saving
      if (includeWatermark) {
          worker.get('pdf').then((pdf: any) => {
              const totalPages = pdf.internal.getNumberOfPages();
              const pageWidth = pdf.internal.pageSize.getWidth();
              const pageHeight = pdf.internal.pageSize.getHeight();

              for (let i = 1; i <= totalPages; i++) {
                  pdf.setPage(i);
                  
                  // Save graphics state to handle transparency
                  pdf.saveGraphicsState();
                  pdf.setGState(new pdf.GState({opacity: 0.15}));
                  
                  pdf.setFontSize(40);
                  pdf.setTextColor(150);
                  
                  // Calculate center
                  const text = "FPX ReelVision";
                  const textWidth = pdf.getStringUnitWidth(text) * 40 / pdf.internal.scaleFactor;
                  
                  // Rotate and draw text in center of page
                  pdf.text(text, pageWidth / 2, pageHeight / 2, {
                      align: 'center',
                      angle: 45,
                      renderingMode: 'fill'
                  });
                  
                  pdf.restoreGraphicsState();
              }
          }).save();
      } else {
          worker.save();
      }

    } catch (err) {
      console.error("PDF generation failed", err);
      alert("Could not generate PDF. Please ensure all images are loaded.");
    } finally {
      setIsDownloadingPdf(false);
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto animate-fade-in">
      <div className="mb-6 flex flex-col md:flex-row items-center justify-between gap-4">
         <div className="flex items-center gap-4 w-full md:w-auto">
             <button onClick={onBack} className="p-2 hover:bg-cine-800 rounded-full text-gray-400 hover:text-white transition-colors">
                 <ArrowLeft className="w-5 h-5" />
             </button>
             <div>
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                   {scene.title}
                </h2>
                <div className="flex items-center gap-3 text-xs text-gray-400 font-mono mt-1">
                    <span className="uppercase tracking-widest">Scene Timeline</span>
                    <span className="w-px h-3 bg-gray-600"></span>
                    <span className="flex items-center gap-1 text-cine-accent"><Clock className="w-3 h-3" /> Runtime: {formatRuntime(totalRuntime)}</span>
                </div>
             </div>
         </div>

         <div className="flex flex-wrap items-center gap-2">
            {/* Visual Style Selector */}
            <div className="flex items-center gap-2 bg-cine-800 rounded-lg px-3 py-1.5 border border-cine-700 mr-2">
                <Palette className="w-4 h-4 text-cine-accent" />
                <select 
                    value={visualStyle}
                    onChange={(e) => setVisualStyle(e.target.value)}
                    className="bg-transparent text-sm text-white focus:outline-none cursor-pointer"
                >
                    {VISUAL_STYLES.map(style => (
                        <option key={style} value={style} className="bg-cine-800">{style} Style</option>
                    ))}
                </select>
            </div>

            <button
                onClick={handleBatchGenerate}
                disabled={isBatchGenerating || shots.every(s => s.imageUrl)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                  isBatchGenerating 
                    ? 'bg-cine-700 text-cine-accent' 
                    : 'bg-cine-accent hover:bg-yellow-500 text-cine-900 shadow-lg shadow-amber-900/20'
                } disabled:opacity-50 disabled:shadow-none disabled:bg-cine-800 disabled:text-gray-500`}
                title="Automatically generate images for all shots one by one"
            >
                {isBatchGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {isBatchGenerating ? 'Generating All...' : 'Generate All'}
            </button>

            <div className="h-6 w-px bg-cine-700 mx-2 hidden md:block"></div>

            <button
                onClick={() => setActiveTab('visual')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${activeTab === 'visual' ? 'bg-cine-700 text-white' : 'text-gray-400 hover:text-white hover:bg-cine-800'}`}
            >
                <List className="w-4 h-4" /> Shots
            </button>
            <button
                onClick={() => setActiveTab('json')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${activeTab === 'json' ? 'bg-cine-700 text-white' : 'text-gray-400 hover:text-white hover:bg-cine-800'}`}
            >
                <Code className="w-4 h-4" /> JSON
            </button>
            
            <div className="flex items-center gap-2 bg-cine-800 p-1 rounded-lg border border-cine-700">
                <button
                    onClick={handleExportCsv}
                    className="px-3 py-1.5 rounded-md text-sm font-medium bg-cine-900 text-gray-300 hover:text-white hover:bg-cine-700 transition-colors flex items-center gap-2 border border-transparent hover:border-cine-600"
                    title="Export as CSV for Excel/Sheets"
                >
                    <Table className="w-4 h-4" /> CSV
                </button>
                <button
                    onClick={handleDownloadPDF}
                    disabled={isDownloadingPdf}
                    className="px-3 py-1.5 rounded-md text-sm font-medium bg-white text-cine-900 hover:bg-gray-200 transition-colors flex items-center gap-2"
                >
                    {isDownloadingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />} 
                    Export PDF
                </button>
                <button 
                    onClick={() => setIncludeWatermark(!includeWatermark)}
                    className="p-1.5 hover:bg-cine-700 rounded text-gray-400 hover:text-white transition-colors"
                    title={includeWatermark ? "Watermark ON" : "Watermark OFF"}
                >
                    {includeWatermark ? <CheckSquare className="w-4 h-4 text-cine-accent" /> : <Square className="w-4 h-4" />}
                </button>
            </div>
        </div>
      </div>

      {/* Content Wrapper for PDF Generation */}
      <div id="storyboard-content" className="bg-cine-900 text-cine-text p-2 rounded-lg">
        {/* Title visible only in PDF/Print usually, but kept here for context if needed. 
            The SceneInfo is good to have on the first page. */}
        <SceneInfo summary={scene.summary} />
        
        {/* Force break after summary so shots start on a clean layout */}
        <div className="page-break" />

        {activeTab === 'visual' ? (
          <div className="space-y-6">
            {shots.map((shot, index) => (
              <React.Fragment key={shot.id}>
                {/* Wrap in break-inside-avoid to prevent card from being split across pages */}
                <div className="break-inside-avoid">
                    <ShotCard 
                        shot={shot} 
                        onGenerateImage={handleGenerateImage} 
                        onUpdateShot={handleUpdateShot}
                        onUpdateNotes={handleUpdateNotes}
                        characters={characters}
                        assets={assets}
                    />
                </div>
                
                {/* Insert Page Break after every 4th shot (4, 8, 12...) but NOT after the last shot */}
                {(index + 1) % 4 === 0 && index !== shots.length - 1 && (
                    <div className="page-break"></div>
                )}
              </React.Fragment>
            ))}
          </div>
        ) : (
          <div className="bg-cine-900 p-6 rounded-xl border border-cine-700 overflow-x-auto">
            <pre className="text-xs md:text-sm font-mono text-green-400">
              {JSON.stringify({ summary: scene.summary, shots }, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
import React from 'react';
import { Activity, Zap, BrainCircuit, Clock, ExternalLink } from 'lucide-react';

export const ApiQuotaReport: React.FC = () => {
  return (
    <div className="bg-cine-900/50 border border-cine-800 rounded-2xl p-8 max-w-4xl mx-auto relative overflow-hidden animate-fade-in">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"></div>
        
        <div className="flex flex-col md:flex-row gap-8">
            <div className="flex-1">
                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    <Activity className="w-6 h-6 text-cine-accent" /> 
                    API Quota Status <span className="text-xs font-normal text-gray-500 bg-cine-800 px-2 py-1 rounded-full border border-cine-700">Free Tier</span>
                </h2>
                
                <div className="space-y-6">
                    <div>
                        <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">Model Limits (Estimated)</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-cine-800 p-4 rounded-lg border border-cine-700 hover:border-cine-500 transition-colors">
                                <div className="flex items-center gap-2 mb-2">
                                    <Zap className="w-4 h-4 text-green-400" />
                                    <span className="font-bold text-white">Gemini 1.5 Flash</span>
                                </div>
                                <div className="text-2xl font-mono text-white mb-1">1,500 <span className="text-xs text-gray-500">RPD</span></div>
                                <div className="text-xs text-gray-400">15 Requests Per Minute</div>
                            </div>
                            <div className="bg-cine-800 p-4 rounded-lg border border-cine-700 hover:border-cine-500 transition-colors">
                                <div className="flex items-center gap-2 mb-2">
                                    <BrainCircuit className="w-4 h-4 text-purple-400" />
                                    <span className="font-bold text-white">Gemini 1.5 Pro</span>
                                </div>
                                <div className="text-2xl font-mono text-white mb-1">50 <span className="text-xs text-gray-500">RPD</span></div>
                                <div className="text-xs text-gray-400">2 Requests Per Minute</div>
                            </div>
                        </div>
                    </div>

                    <div>
                            <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Quota Reset</h3>
                            <p className="text-gray-300 text-sm flex items-center gap-2">
                            <Clock className="w-4 h-4 text-cine-accent" />
                            Daily limits reset at <span className="font-bold text-white">Midnight Pacific Time (PT)</span>.
                            </p>
                    </div>
                </div>
            </div>

            <div className="md:w-72 bg-cine-800/50 rounded-xl p-6 border border-cine-700 flex flex-col justify-between">
                <div>
                    <h3 className="text-white font-bold mb-2">Real-time Usage</h3>
                    <p className="text-xs text-gray-400 mb-6">
                        We cannot display your exact remaining quota here. Please check Google AI Studio for live data.
                    </p>
                </div>
                
                <div className="space-y-3">
                    <a 
                        href="https://aistudio.google.com/app/plan_information" 
                        target="_blank" 
                        rel="noreferrer"
                        className="flex items-center justify-center gap-2 w-full py-2 bg-cine-700 hover:bg-white hover:text-cine-900 text-white rounded-lg text-sm font-medium transition-colors"
                    >
                        <ExternalLink className="w-4 h-4" /> View Usage Dashboard
                    </a>
                    
                    <div className="bg-amber-900/20 border border-amber-900/50 rounded-lg p-3">
                        <p className="text-[10px] text-amber-200 leading-tight">
                            <span className="font-bold block mb-1">Running low?</span>
                            Our system automatically switches to <strong>Flash-Lite</strong> if your Pro quota runs out. No interruption.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};
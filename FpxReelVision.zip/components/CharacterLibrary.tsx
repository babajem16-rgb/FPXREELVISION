import React, { useState, useRef } from 'react';
import { Character } from '../types';
import { generateCharacterSketch } from '../services/gemini';
import { User, Image as ImageIcon, Sparkles, Loader2, Upload, Trash2, Maximize2 } from 'lucide-react';

interface CharacterLibraryProps {
  characters: Character[];
  setCharacters: React.Dispatch<React.SetStateAction<Character[]>>;
}

export const CharacterLibrary: React.FC<CharacterLibraryProps> = ({ characters, setCharacters }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Form State
  const [name, setName] = useState('');
  const [traits, setTraits] = useState('');
  const [style, setStyle] = useState('Storyboard Sketch');
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    if (!name) return;
    
    setIsGenerating(true);
    try {
      const sketchUrl = await generateCharacterSketch(name, referenceImage, traits, style);
      
      const newCharacter: Character = {
        id: Date.now().toString(),
        character_name: name,
        reference_image: referenceImage,
        sketch_image: sketchUrl,
        style: style,
        traits: traits,
        created_at: new Date().toISOString()
      };

      setCharacters(prev => [...prev, newCharacter]);
      
      // Reset critical form fields (optional)
      setName('');
      setTraits('');
    } catch (error: any) {
      alert(error.message || "Failed to generate character sketch. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDelete = (id: string) => {
    setCharacters(prev => prev.filter(c => c.id !== id));
  };

  return (
    <div className="w-full max-w-6xl mx-auto animate-fade-in space-y-8">
      
      {/* Creation Form */}
      <div className="bg-cine-800 rounded-xl p-6 border border-cine-700 shadow-xl">
        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <User className="w-6 h-6 text-cine-accent" />
          Create New Character
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Character Name</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Detective Miller"
                className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Traits & Details</label>
              <textarea 
                value={traits}
                onChange={(e) => setTraits(e.target.value)}
                placeholder="Age, personality, outfit (e.g. 40s, weary, trench coat, fedora)"
                rows={3}
                className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none resize-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-1">Art Style</label>
              <select 
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full bg-cine-900 border border-cine-700 rounded-lg p-3 text-white focus:ring-1 focus:ring-cine-accent outline-none"
              >
                <option value="Storyboard Sketch">Storyboard Sketch</option>
                <option value="Realistic">Realistic</option>
                <option value="Anime">Anime</option>
                <option value="Noir">Film Noir</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-gray-400 mb-1">Reference Image (Optional)</label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="w-full h-48 border-2 border-dashed border-cine-600 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-cine-accent hover:bg-cine-900/50 transition-all relative overflow-hidden group"
            >
               {referenceImage ? (
                 <>
                   <img src={referenceImage} alt="Reference" className="w-full h-full object-cover opacity-60 group-hover:opacity-40 transition-opacity" />
                   <div className="absolute inset-0 flex items-center justify-center">
                      <span className="bg-black/70 text-white text-xs px-2 py-1 rounded">Click to change</span>
                   </div>
                 </>
               ) : (
                 <>
                   <Upload className="w-8 h-8 text-cine-500 mb-2" />
                   <span className="text-sm text-cine-400">Upload Reference Image</span>
                 </>
               )}
               <input 
                 type="file" 
                 ref={fileInputRef} 
                 onChange={handleImageUpload} 
                 accept="image/*" 
                 className="hidden" 
               />
            </div>
            
            <button
              onClick={handleGenerate}
              disabled={isGenerating || !name}
              className={`w-full py-3 rounded-lg font-semibold text-white flex items-center justify-center gap-2 transition-all mt-auto
                ${isGenerating || !name ? 'bg-cine-700 cursor-not-allowed' : 'bg-cine-accent hover:bg-yellow-500 shadow-lg shadow-amber-900/20'}
              `}
            >
              {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              {isGenerating ? 'Generating Sketch...' : 'Generate Character'}
            </button>
          </div>
        </div>
      </div>

      {/* Library Grid */}
      <div>
        <h3 className="text-lg font-bold text-white mb-4">Character Library</h3>
        {characters.length === 0 ? (
          <div className="text-center py-12 text-gray-500 border border-cine-800 rounded-xl bg-cine-900/30">
            <User className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p>No characters generated yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {characters.map(char => (
              <div key={char.id} className="bg-cine-900 border border-cine-700 rounded-xl overflow-hidden group relative hover:border-cine-600 transition-colors">
                <div className="aspect-[4/5] relative bg-black">
                  <img src={char.sketch_image} alt={char.character_name} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                     <p className="text-xs text-gray-300 line-clamp-2 italic">{char.traits}</p>
                  </div>
                  <button 
                    onClick={() => window.open(char.sketch_image, '_blank')}
                    className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="p-4 flex items-center justify-between border-t border-cine-800">
                  <div>
                    <h4 className="font-bold text-white">{char.character_name}</h4>
                    <span className="text-xs text-cine-400 font-mono">{char.style}</span>
                  </div>
                  <button 
                    onClick={() => handleDelete(char.id)}
                    className="text-gray-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
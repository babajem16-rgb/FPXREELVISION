import React from 'react';
import { SceneSummary } from '../types';
import { MapPin, Users, Package, Clock, Moon } from 'lucide-react';

interface SceneInfoProps {
  summary: SceneSummary;
}

export const SceneInfo: React.FC<SceneInfoProps> = ({ summary }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {/* Location Card */}
      <div className="bg-cine-800 p-4 rounded-lg border border-cine-700 flex items-start gap-3">
        <div className="p-2 bg-cine-900 rounded-md text-cine-accent">
          <MapPin className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Location</h3>
          <p className="text-sm font-medium text-cine-text">{summary.location}</p>
        </div>
      </div>

      {/* Time/Mood Card */}
      <div className="bg-cine-800 p-4 rounded-lg border border-cine-700 flex items-start gap-3">
        <div className="p-2 bg-cine-900 rounded-md text-cine-accent">
          <Moon className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Time & Mood</h3>
          <p className="text-sm font-medium text-cine-text">{summary.timeOfDay} • {summary.overallMood}</p>
        </div>
      </div>

      {/* Characters Card */}
      <div className="bg-cine-800 p-4 rounded-lg border border-cine-700 flex items-start gap-3">
        <div className="p-2 bg-cine-900 rounded-md text-cine-accent">
          <Users className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Characters</h3>
          <div className="flex flex-wrap gap-1 mt-1">
            {summary.characters.map((char, i) => (
              <span key={i} className="text-xs bg-cine-700 px-2 py-0.5 rounded text-gray-200">
                {char}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Props Card */}
      <div className="bg-cine-800 p-4 rounded-lg border border-cine-700 flex items-start gap-3">
        <div className="p-2 bg-cine-900 rounded-md text-cine-accent">
          <Package className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Key Props</h3>
          <div className="flex flex-wrap gap-1 mt-1">
            {summary.props.map((prop, i) => (
              <span key={i} className="text-xs bg-cine-700 px-2 py-0.5 rounded text-gray-200">
                {prop}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { Project, Scene } from '../types';
import { ArrowLeft, Plus, MapPin, Moon, FileText, ChevronRight, PlayCircle, Film, Clock, Trash2, Calendar, Settings } from 'lucide-react';

interface ProjectDetailProps {
  project: Project;
  onBack: () => void;
  onAddScene: () => void;
  onOpenScene: (sceneId: string) => void;
  onDeleteProject: (projectId: string) => void;
  onDeleteScene: (sceneId: string) => void;
}

export const ProjectDetail: React.FC<ProjectDetailProps> = ({ project, onBack, onAddScene, onOpenScene, onDeleteProject, onDeleteScene }) => {
  return (
    <div className="w-full animate-fade-in pb-20">
      
      {/* Hero Header */}
      <div className="relative w-full h-64 md:h-80 rounded-2xl overflow-hidden mb-10 shadow-2xl border border-cine-800 group">
          {/* Background Image with Gradient Overlay */}
          <img 
            src={project.coverImage} 
            alt={project.title} 
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-cine-900 via-cine-900/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-cine-900/90 via-cine-900/40 to-transparent" />

          {/* Content */}
          <div className="absolute bottom-0 left-0 w-full p-6 md:p-10 flex flex-col md:flex-row items-start md:items-end justify-between gap-6">
              <div className="max-w-2xl">
                   <div className="flex items-center gap-3 text-cine-accent font-mono text-xs uppercase tracking-widest mb-2">
                       <span className="bg-cine-accent/10 px-2 py-1 rounded border border-cine-accent/20">Feature Film</span>
                       <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(project.createdAt).toLocaleDateString()}</span>
                   </div>
                   <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight mb-3 drop-shadow-lg">{project.title}</h1>
                   <p className="text-gray-300 text-lg leading-relaxed line-clamp-2 drop-shadow-md">{project.description}</p>
              </div>

              <div className="flex items-center gap-3">
                   <button 
                        onClick={() => onDeleteProject(project.id)}
                        className="p-3 bg-black/40 hover:bg-red-900/50 text-gray-300 hover:text-red-200 rounded-xl backdrop-blur-md border border-white/10 transition-colors"
                        title="Delete Project"
                   >
                       <Trash2 className="w-5 h-5" />
                   </button>
                   <button 
                        className="p-3 bg-black/40 hover:bg-white/10 text-gray-300 hover:text-white rounded-xl backdrop-blur-md border border-white/10 transition-colors"
                        title="Project Settings"
                   >
                       <Settings className="w-5 h-5" />
                   </button>
                   <button 
                        onClick={onAddScene}
                        className="flex items-center gap-2 px-6 py-3 bg-cine-accent hover:bg-yellow-400 text-cine-900 rounded-xl font-bold shadow-lg shadow-amber-900/20 transition-all hover:scale-105 active:scale-95"
                   >
                        <Plus className="w-5 h-5" /> Add New Scene
                   </button>
              </div>
          </div>
      </div>

      {/* Scenes Section */}
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                <span className="bg-cine-800 p-2 rounded-lg text-cine-accent"><FileText className="w-5 h-5" /></span>
                Production Scenes
                <span className="text-sm font-normal text-gray-500 ml-2">({project.scenes.length} total)</span>
            </h2>
            
            {/* Filter/Sort controls could go here */}
        </div>

        {project.scenes.length === 0 ? (
           <div className="bg-cine-800/50 border-2 border-dashed border-cine-700 rounded-2xl p-16 text-center hover:bg-cine-800/80 transition-colors group cursor-pointer" onClick={onAddScene}>
               <div className="w-16 h-16 bg-cine-900 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform shadow-xl shadow-black/20">
                   <Plus className="w-8 h-8 text-cine-500 group-hover:text-cine-accent transition-colors" />
               </div>
               <h3 className="text-xl font-bold text-white mb-2">Start Your Script Breakdown</h3>
               <p className="text-gray-500 max-w-md mx-auto mb-6">Import your script to automatically generate shot lists, storyboards, and call sheets.</p>
               <button className="text-cine-accent hover:text-white font-medium underline underline-offset-4">Create Scene 1</button>
           </div>
        ) : (
            <div className="space-y-4">
                {project.scenes.map((scene, index) => (
                    <div 
                        key={scene.id}
                        onClick={() => onOpenScene(scene.id)}
                        className="group bg-cine-800 border border-cine-700 hover:border-cine-500 rounded-xl p-1 cursor-pointer transition-all hover:shadow-xl hover:shadow-cine-950/50 flex relative overflow-hidden"
                    >
                        {/* Scene Strip Decoration */}
                        <div className="w-2 bg-cine-700 group-hover:bg-cine-accent transition-colors rounded-l-lg absolute top-0 bottom-0 left-0 z-10"></div>
                        
                        <div className="flex-1 p-5 pl-7 flex items-center justify-between gap-6 z-0">
                            <div className="flex items-center gap-6">
                                <div className="flex flex-col items-center justify-center w-14 h-14 bg-cine-900 rounded-lg border border-cine-700 group-hover:border-cine-600 transition-colors shadow-inner">
                                    <span className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">SCENE</span>
                                    <span className="text-2xl font-bold text-white group-hover:text-cine-accent transition-colors font-mono">{index + 1}</span>
                                </div>
                                
                                <div>
                                    <h3 className="text-xl font-bold text-white mb-1.5 group-hover:text-cine-accent transition-colors">{scene.title}</h3>
                                    <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-gray-400">
                                        <span className="flex items-center gap-1.5 px-2 py-1 bg-cine-900 rounded border border-cine-700/50">
                                            <MapPin className="w-3 h-3 text-cine-500" /> {scene.summary.location}
                                        </span>
                                        <span className="flex items-center gap-1.5 px-2 py-1 bg-cine-900 rounded border border-cine-700/50">
                                            <Moon className="w-3 h-3 text-cine-500" /> {scene.summary.timeOfDay}
                                        </span>
                                        <span className="flex items-center gap-1.5 px-2 py-1 bg-cine-900 rounded border border-cine-700/50">
                                            <Film className="w-3 h-3 text-cine-500" /> {scene.shots.length} Shots
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className="flex items-center gap-6">
                                {/* Character Faces */}
                                <div className="hidden md:flex items-center -space-x-2 mr-4">
                                     {scene.summary.characters.length > 0 ? scene.summary.characters.slice(0, 4).map((char, i) => (
                                         <div key={i} className="w-8 h-8 rounded-full bg-cine-700 border-2 border-cine-800 flex items-center justify-center text-[10px] text-white font-bold shadow-sm" title={char}>
                                             {char[0]}
                                         </div>
                                     )) : <span className="text-xs text-gray-600 italic">No cast</span>}
                                </div>

                                <div className="h-10 w-px bg-cine-700 mx-2 hidden sm:block"></div>
                                
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onDeleteScene(scene.id); }}
                                    className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-900/10 rounded-lg transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                                    title="Delete Scene"
                                >
                                    <Trash2 className="w-5 h-5" />
                                </button>

                                <div className="bg-cine-900 rounded-full p-2 group-hover:bg-cine-accent group-hover:text-cine-900 transition-colors">
                                     <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-cine-900" />
                                </div>
                            </div>
                        </div>
                    </div>
                ))
            )}
            </div>
        )}
      </div>
    </div>
  );
};

export interface Shot {
  id: number;
  shotNumber: number;
  cameraAngle: string;
  shotType: string;
  framing: string;
  action: string;
  lightingMood: string;
  sketchPrompt: string; // The instruction for the sketch
  estimatedDuration: number; // In seconds
  lens: string; // e.g., "35mm", "50mm", "85mm"
  imageUrl?: string; // Generated image URL
  isGeneratingImage?: boolean;
  userNotes?: string; // Custom notes from the user
}

export interface SceneSummary {
  characters: string[];
  props: string[];
  location: string;
  overallMood: string;
  timeOfDay: string;
}

export interface AnalysisResult {
  summary: SceneSummary;
  shots: Shot[];
}

export interface Scene {
  id: string;
  sceneNumber: number;
  title: string; // Derived from location/slugline usually
  scriptContent: string;
  summary: SceneSummary;
  shots: Shot[];
  createdAt: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  coverImage?: string;
  createdAt: string;
  scenes: Scene[];
}

export interface Character {
  id: string;
  character_name: string;
  reference_image: string | null; // Base64 of user upload
  sketch_image: string; // Base64 of generated sketch
  style: string;
  traits: string; // Combined age, personality, outfit
  created_at: string;
}

export interface Asset {
  id: string;
  name: string;
  type: 'Location' | 'Vehicle' | 'Prop' | 'Equipment';
  description: string;
  reference_image: string | null;
  sketch_image: string;
  style: string;
  created_at: string;
}

export enum AppState {
  IDLE = 'IDLE',
  ANALYZING = 'ANALYZING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export type ViewMode = 'HOME' | 'PROJECTS_LIST' | 'PROJECT_DETAIL' | 'SCENE_DETAIL' | 'CHARACTERS' | 'ASSETS' | 'NEW_SCENE' | 'API_LIMITS';

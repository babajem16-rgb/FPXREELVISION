import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult, Character, Asset } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ANALYSIS_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    summary: {
      type: Type.OBJECT,
      properties: {
        characters: { type: Type.ARRAY, items: { type: Type.STRING } },
        props: { type: Type.ARRAY, items: { type: Type.STRING } },
        location: { type: Type.STRING },
        overallMood: { type: Type.STRING },
        timeOfDay: { type: Type.STRING },
      },
      required: ["characters", "props", "location", "overallMood", "timeOfDay"],
    },
    shots: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          shotNumber: { type: Type.INTEGER },
          cameraAngle: { type: Type.STRING, description: "e.g., Low Angle, High Angle, Eye Level, Dutch Angle" },
          shotType: { type: Type.STRING, description: "e.g., Static, Handheld, Dolly, Crane, Drone" },
          framing: { type: Type.STRING, description: "e.g., ECU, CU, MS, WS, EWS, OTS" },
          action: { type: Type.STRING, description: "Brief description of action in shot" },
          lightingMood: { type: Type.STRING },
          sketchPrompt: { type: Type.STRING, description: "Detailed visual description for an artist to draw this frame. Include style notes." },
          estimatedDuration: { type: Type.INTEGER, description: "Estimated duration in seconds based on action/dialogue length." },
          lens: { type: Type.STRING, description: "Suggested camera lens (e.g. 16mm, 35mm, 50mm, 85mm, 200mm)" },
        },
        required: ["shotNumber", "cameraAngle", "shotType", "framing", "action", "lightingMood", "sketchPrompt", "estimatedDuration", "lens"],
      },
    },
  },
  required: ["summary", "shots"],
};

// Robust error message extractor to handle various API error formats
const getErrorDetails = (error: any): string => {
    if (typeof error === 'string') return error.toLowerCase();
    
    let msg = error?.message || "";
    
    // Check for nested error object (Common in Google APIs)
    if (error?.error?.message) {
        msg += " " + error.error.message;
    }
    
    // If message is generic or missing, try stringify to catch codes
    if (!msg || msg === "[object Object]") {
        try {
            msg = JSON.stringify(error);
        } catch {}
    }
    
    return msg.toLowerCase();
};

const handleGeminiError = (error: any): never => {
  console.error("Gemini API Error:", error);
  const msg = getErrorDetails(error);
  
  if (
    msg.includes('429') || 
    msg.includes('quota') || 
    msg.includes('resource has been exhausted')
  ) {
    throw new Error("All API Quotas Exceeded. Please try again later or use the placeholder mode.");
  }

  if (
      msg.includes('404') || 
      msg.includes('not found') || 
      msg.includes('requested entity was not found')
  ) {
    throw new Error("AI Models unavailable. The feature has been disabled temporarily.");
  }
  
  throw error;
};

// --- Multi-Strategy Fallback Logic ---
// Attempts every strategy in the list before failing or using placeholder
async function withModelFallback<T>(
  operationName: string,
  strategies: (() => Promise<T>)[],
  placeholderFn?: () => T
): Promise<T> {
  let lastError: any;

  for (const [index, strategy] of strategies.entries()) {
    try {
      if (index > 0) {
        console.warn(`[${operationName}] Switching to fallback strategy ${index + 1}/${strategies.length}...`);
      }
      return await strategy();
    } catch (error: any) {
      lastError = error;
      const msg = getErrorDetails(error);
      
      // Log specifically if it was a quota error to inform the developer
      if (msg.includes('quota') || msg.includes('429') || msg.includes('exhausted')) {
         console.warn(`[${operationName}] Strategy ${index + 1} Quota Exceeded: ${msg}`);
      } else {
         console.warn(`[${operationName}] Strategy ${index + 1} failed: ${msg}`);
      }

      // Continue to next strategy loop
    }
  }

  // If all strategies failed
  if (placeholderFn) {
      console.warn(`[${operationName}] All strategies failed. Using placeholder/mock data.`);
      return placeholderFn();
  }

  console.error(`[${operationName}] Fallback model also failed.`);
  throw lastError;
}

// Generate a placeholder image URL for UI continuity when AI fails
const getPlaceholderImage = (text: string, bgColor = "1e293b", textColor = "94a3b8") => {
    const encodedText = encodeURIComponent(text.length > 50 ? text.substring(0, 47) + "..." : text);
    // Using a reliable placeholder service
    return `https://placehold.co/1024x576/${bgColor}/${textColor}?text=${encodedText}&font=roboto`;
};

// Helper to generate SVG using text models (Gemini 1.5) as a deep fallback for images
const generateFallbackSvg = async (model: string, description: string, aspectRatio: string): Promise<string> => {
    // Determine dimensions based on aspect ratio
    let width = 1024;
    let height = 576; // 16:9
    if (aspectRatio === '3:4') { width = 768; height = 1024; }
    else if (aspectRatio === '4:3') { width = 1024; height = 768; }
    else if (aspectRatio === '1:1') { width = 1024; height = 1024; }

    const svgPrompt = `
      You are a technical artist. Generate a Scalable Vector Graphic (SVG) code to visually represent: 
      "${description}"
      
      Requirements:
      - Dimensions: ${width}x${height} (ViewBox="0 0 ${width} ${height}")
      - Style: Cinematic storyboard sketch, monochrome line art, minimalist, high contrast. 
      - Color: Black strokes on white/transparent background, or grayscale.
      - OUTPUT: Return ONLY the raw <svg>...</svg> code string. Do NOT use markdown code blocks.
    `;

    const response = await ai.models.generateContent({
        model: model,
        contents: svgPrompt,
        config: { responseMimeType: "text/plain" }
    });

    let text = response.text;
    if (!text) throw new Error("No SVG output");

    // Clean markdown if present
    text = text.replace(/```xml/gi, '').replace(/```svg/gi, '').replace(/```/g, '').trim();
    
    const start = text.indexOf('<svg');
    const end = text.lastIndexOf('</svg>');
    if (start === -1 || end === -1) throw new Error("Invalid SVG");

    const svgData = text.substring(start, end + 6);
    
    // Encode SVG to Data URI (handling unicode characters safely)
    const base64 = btoa(unescape(encodeURIComponent(svgData)));
    return `data:image/svg+xml;base64,${base64}`;
};

// --- Script Analysis Service ---
export const analyzeScript = async (scriptText: string): Promise<AnalysisResult> => {
  const systemInstruction = "You are a world-class Cinematographer. Translate text into visual language.";
  const prompt = `
    Analyze the following movie script content.
    
    Instructions:
    1. Break down the script into practical shots.
    2. Estimate the duration of each shot (1 sec per line of action, 3 sec per line of dialogue).
    3. Suggest an appropriate camera lens (e.g. 35mm for wides, 85mm for closeups).
    4. 'sketchPrompt' MUST BE IN ENGLISH.
    5. Use specific Character Names in 'sketchPrompt'.
    
    Script:
    """
    ${scriptText}
    """
  `;

  const requestConfig = {
    responseMimeType: "application/json",
    responseSchema: ANALYSIS_SCHEMA,
    systemInstruction,
  };

  const strategies = [
      // 1. Primary: Gemini 3 Flash (Latest, Optimized for tasks)
      async () => {
        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
            config: requestConfig,
        });
        return response.text;
      },
      // 2. Secondary: Gemini Flash Lite (Highest Quota, Fast)
      async () => {
        const response = await ai.models.generateContent({
            model: "gemini-flash-lite-latest",
            contents: prompt,
            config: requestConfig,
        });
        return response.text;
      },
      // 3. Fallback: Gemini 2.5 Flash (Legacy/Stable)
      async () => {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash", 
            contents: prompt,
            config: requestConfig,
        });
        return response.text;
      },
      // 4. Deep Fallback: Gemini 1.5 Flash (Previous Gen, High Quota)
      async () => {
        const response = await ai.models.generateContent({
            model: "gemini-1.5-flash", 
            contents: prompt,
            config: requestConfig,
        });
        return response.text;
      },
      // 5. Deep Fallback: Gemini 1.5 Pro (Previous Gen, Strong Reasoning)
      async () => {
        const response = await ai.models.generateContent({
            model: "gemini-1.5-pro", 
            contents: prompt,
            config: requestConfig,
        });
        return response.text;
      },
      // 6. Last Resort: Gemini 2.0 Flash Exp (Experimental)
      async () => {
        const response = await ai.models.generateContent({
            model: "gemini-2.0-flash-exp", 
            contents: prompt,
            config: requestConfig,
        });
        return response.text;
      }
  ];

  try {
    const text = await withModelFallback("analyzeScript", strategies);
    
    if (!text) throw new Error("No response from AI");
    
    const data = JSON.parse(text);
    return {
      summary: data.summary,
      shots: data.shots.map((shot: any, index: number) => ({ 
        ...shot, 
        id: index + 1,
        // Fallbacks if model omits new fields
        estimatedDuration: shot.estimatedDuration || 5,
        lens: shot.lens || "35mm"
      }))
    };

  } catch (error) {
    handleGeminiError(error);
  }
};

// --- Storyboard Image Generation ---
export const generateStoryboardImage = async (
  prompt: string, 
  style: string = "Cinematic Noir",
  characters: Character[] = [],
  assets: Asset[] = []
): Promise<string> => {
  
  // Style Logic
  let stylePrompt = "";
  switch (style) {
      case "Realistic": stylePrompt = "Photorealistic movie still, 4k, highly detailed, cinematic lighting."; break;
      case "Anime": stylePrompt = "Anime style, high quality animation cell, vibrant colors."; break;
      case "Sketch": stylePrompt = "Rough pencil sketch storyboard, black and white."; break;
      case "Watercolor": stylePrompt = "Watercolor concept art, artistic, flowing colors."; break;
      default: stylePrompt = "Cinematic black and white storyboard sketch, noir atmosphere."; break;
  }

  // Build Parts
  const parts: any[] = [];
  const promptLower = prompt.toLowerCase();
  let visualReferencesInstruction = "";
  let refCounter = 1;

  // Characters
  characters.forEach((char) => {
    const nameParts = char.character_name.toLowerCase().split(/\s+/);
    if (promptLower.includes(char.character_name.toLowerCase()) || nameParts.some(p => p.length >= 2 && promptLower.includes(p))) {
      const base64Data = char.sketch_image.split(',')[1] || char.sketch_image;
      parts.push({ inlineData: { data: base64Data, mimeType: "image/png" } });
      visualReferencesInstruction += `\n- Reference Image ${refCounter}: Character "${char.character_name}".`;
      refCounter++;
    }
  });

  // Assets
  assets.forEach((asset) => {
    const nameParts = asset.name.toLowerCase().split(/\s+/);
    if (promptLower.includes(asset.name.toLowerCase()) || nameParts.some(p => p.length >= 3 && promptLower.includes(p))) {
      const base64Data = asset.sketch_image.split(',')[1] || asset.sketch_image;
      parts.push({ inlineData: { data: base64Data, mimeType: "image/png" } });
      visualReferencesInstruction += `\n- Reference Image ${refCounter}: Asset "${asset.name}".`;
      refCounter++;
    }
  });

  const finalPrompt = `
    Create a storyboard image.
    Style: ${stylePrompt}
    Scene Description: ${prompt}
    ${visualReferencesInstruction}
    If references provided, maintain consistency.
  `;
  parts.push({ text: finalPrompt });

  const extractGeminiImage = (response: any) => {
    const imagePart = response.candidates?.[0]?.content?.parts?.find((p: any) => p.inlineData);
    if (imagePart?.inlineData?.data) {
      return `data:${imagePart.inlineData.mimeType || 'image/png'};base64,${imagePart.inlineData.data}`;
    }
    throw new Error("No image generated by Gemini");
  };

  const strategies = [
      // 1. Primary: Gemini 2.5 Flash Image (Fast, supports references)
      async () => {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: { parts },
        });
        return extractGeminiImage(response);
      },
      // 2. Secondary: Gemini 3 Pro Image (Higher Quality, supports references)
      async () => {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: { parts },
        });
        return extractGeminiImage(response);
      },
      // 3. Fallback: Imagen 3 (Text only, drops references but works as backup)
      async () => {
         const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-001',
            prompt: finalPrompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '16:9',
            },
        });
        const base64 = response.generatedImages?.[0]?.image?.imageBytes;
        if (base64) return `data:image/jpeg;base64,${base64}`;
        throw new Error("No image generated by Imagen");
      },
      // 4. Deep Fallback: Gemini 1.5 Pro (Generate SVG)
      async () => generateFallbackSvg("gemini-1.5-pro", prompt, '16:9'),
      
      // 5. Deep Fallback: Gemini 1.5 Flash (Generate SVG)
      async () => generateFallbackSvg("gemini-1.5-flash", prompt, '16:9'),
  ];

  try {
    return await withModelFallback(
        "generateStoryboardImage", 
        strategies, 
        () => getPlaceholderImage(prompt)
    );
  } catch (error) {
    handleGeminiError(error);
  }
};

// --- Character Sketch Generation ---
export const generateCharacterSketch = async (
  name: string,
  referenceImageBase64: string | null,
  traits: string,
  style: string
): Promise<string> => {
  const parts: any[] = [];
  if (referenceImageBase64) {
    const base64Data = referenceImageBase64.split(',')[1] || referenceImageBase64;
    parts.push({ inlineData: { data: base64Data, mimeType: "image/png" } });
  }

  const promptText = `Character sketch for "${name}". Traits: ${traits}. Style: ${style}. Simple background.`;
  parts.push({ text: promptText });

  const extractGeminiImage = (response: any) => {
    const imagePart = response.candidates?.[0]?.content?.parts?.find((p: any) => p.inlineData);
    if (imagePart?.inlineData?.data) {
      return `data:${imagePart.inlineData.mimeType || 'image/png'};base64,${imagePart.inlineData.data}`;
    }
    throw new Error("No image generated");
  };

  const strategies = [
      async () => {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: { parts },
        });
        return extractGeminiImage(response);
      },
      async () => {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: { parts },
        });
        return extractGeminiImage(response);
      },
      async () => {
         const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-001',
            prompt: promptText,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '3:4', // Portrait for characters
            },
        });
        const base64 = response.generatedImages?.[0]?.image?.imageBytes;
        if (base64) return `data:image/jpeg;base64,${base64}`;
        throw new Error("No image generated");
      },
      // Deep Fallbacks for Characters (Vertical Aspect Ratio)
      async () => generateFallbackSvg("gemini-1.5-pro", promptText, '3:4'),
      async () => generateFallbackSvg("gemini-1.5-flash", promptText, '3:4'),
  ];

  try {
    return await withModelFallback(
        "generateCharacterSketch", 
        strategies, 
        () => getPlaceholderImage(name, "334155", "e2e8f0")
    );
  } catch (error) {
    handleGeminiError(error);
  }
};

// --- Asset Sketch Generation ---
export const generateAssetSketch = async (
  name: string,
  type: string,
  referenceImageBase64: string | null,
  description: string,
  style: string
): Promise<string> => {
  const parts: any[] = [];
  if (referenceImageBase64) {
    const base64Data = referenceImageBase64.split(',')[1] || referenceImageBase64;
    parts.push({ inlineData: { data: base64Data, mimeType: "image/png" } });
  }

  const promptText = `Concept art for ${type} named "${name}". Description: ${description}. Style: ${style}.`;
  parts.push({ text: promptText });

  const extractGeminiImage = (response: any) => {
    const imagePart = response.candidates?.[0]?.content?.parts?.find((p: any) => p.inlineData);
    if (imagePart?.inlineData?.data) {
      return `data:${imagePart.inlineData.mimeType || 'image/png'};base64,${imagePart.inlineData.data}`;
    }
    throw new Error("No image generated");
  };

  const strategies = [
      async () => {
        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: { parts },
        });
        return extractGeminiImage(response);
      },
      async () => {
        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: { parts },
        });
        return extractGeminiImage(response);
      },
      async () => {
         const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-001',
            prompt: promptText,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '4:3', 
            },
        });
        const base64 = response.generatedImages?.[0]?.image?.imageBytes;
        if (base64) return `data:image/jpeg;base64,${base64}`;
        throw new Error("No image generated");
      },
      // Deep Fallbacks for Assets (Standard Aspect Ratio)
      async () => generateFallbackSvg("gemini-1.5-pro", promptText, '4:3'),
      async () => generateFallbackSvg("gemini-1.5-flash", promptText, '4:3'),
  ];

  try {
    return await withModelFallback(
        "generateAssetSketch", 
        strategies, 
        () => getPlaceholderImage(name, "0f172a", "64748b")
    );
  } catch (error) {
    handleGeminiError(error);
  }
};

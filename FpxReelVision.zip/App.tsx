import React, { useState } from 'react';
import { Clapperboard, Users, LayoutList, AlertTriangle, ChevronRight, Home, Sparkles, Zap, FileText, Wand2, ArrowRight, Box } from 'lucide-react';
import { ScriptForm } from './components/ScriptForm';
import { Dashboard } from './components/Dashboard';
import { CharacterLibrary } from './components/CharacterLibrary';
import { AssetLibrary } from './components/AssetLibrary';
import { ProjectsList } from './components/ProjectsList';
import { ProjectDetail } from './components/ProjectDetail';
import { analyzeScript } from './services/gemini';
import { AppState, Project, Scene, Character, Asset, ViewMode } from './types';

// Dummy Data to start
const MOCK_PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Dardi Ladi',
    description: 'A gritty noir thriller set in the rainy streets of Mumbai.',
    coverImage: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&q=80&w=1925',
    createdAt: new Date().toISOString(),
    scenes: []
  }
];

function App() {
  // Navigation State - Start at HOME
  const [viewMode, setViewMode] = useState<ViewMode>('HOME');
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [activeSceneId, setActiveSceneId] = useState<string | null>(null);

  // Data State
  const [projects, setProjects] = useState<Project[]>(MOCK_PROJECTS);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [projectToDelete, setProjectToDelete] = useState<string | null>(null);
  
  // Analysis State (for creating new scenes)
  const [analysisState, setAnalysisState] = useState<AppState>(AppState.IDLE);

  // Computed Properties for Navigation
  const activeProject = projects.find(p => p.id === activeProjectId);
  const activeScene = activeProject?.scenes.find(s => s.id === activeSceneId);

  // --- Actions ---

  const handleNavigateHome = () => {
    setViewMode('HOME');
    setActiveProjectId(null);
    setActiveSceneId(null);
  };

  const handleNavigateProjectsList = () => {
    setViewMode('PROJECTS_LIST');
    setActiveProjectId(null);
    setActiveSceneId(null);
  };

  const handleNavigateCharacters = () => {
    setViewMode('CHARACTERS');
    setActiveProjectId(null);
    setActiveSceneId(null);
  };

  const handleNavigateAssets = () => {
    setViewMode('ASSETS');
    setActiveProjectId(null);
    setActiveSceneId(null);
  };

  const handleNavigateProjectDetail = () => {
    if (activeProjectId) {
        setViewMode('PROJECT_DETAIL');
        setActiveSceneId(null);
    }
  };

  const handleCreateProject = (projectData: Omit<Project, 'id' | 'createdAt' | 'scenes'>) => {
    const newProject: Project = {
      ...projectData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      scenes: []
    };
    setProjects(prev => [newProject, ...prev]);
    // Optionally auto-navigate to the new project
    setActiveProjectId(newProject.id);
    setViewMode('PROJECT_DETAIL');
  };

  const handleEditProject = (id: string, updates: Partial<Project>) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const handleDeleteProject = (projectId: string) => {
    setProjectToDelete(projectId);
  };

  const confirmDeleteProject = () => {
    if (projectToDelete) {
        setProjects(prev => prev.filter(p => p.id !== projectToDelete));
        // If we are deleting the currently active project, go back to list
        if (activeProjectId === projectToDelete) {
            handleNavigateProjectsList();
        }
        setProjectToDelete(null);
    }
  };

  const handleOpenProject = (projectId: string) => {
    setActiveProjectId(projectId);
    setViewMode('PROJECT_DETAIL');
  };

  const handleCreateScene = async (script: string) => {
    setAnalysisState(AppState.ANALYZING);
    try {
      const data = await analyzeScript(script);
      
      const newScene: Scene = {
        id: Date.now().toString(),
        sceneNumber: (projects.find(p => p.id === activeProjectId)?.scenes.length || 0) + 1,
        title: `${data.summary.location} - ${data.summary.timeOfDay}`,
        scriptContent: script,
        summary: data.summary,
        shots: data.shots,
        createdAt: new Date().toISOString()
      };

      setProjects(prev => prev.map(p => {
        if (p.id === activeProjectId) {
          return { ...p, scenes: [...p.scenes, newScene] };
        }
        return p;
      }));

      setAnalysisState(AppState.SUCCESS);
      setActiveSceneId(newScene.id);
      setViewMode('SCENE_DETAIL');

    } catch (error: any) {
      console.error(error);
      setAnalysisState(AppState.ERROR);
      alert(error.message || "Failed to analyze script.");
    }
  };

  const handleUpdateScene = (updatedScene: Scene) => {
    setProjects(prev => prev.map(p => {
      if (p.id === activeProjectId) {
        return {
          ...p,
          scenes: p.scenes.map(s => s.id === updatedScene.id ? updatedScene : s)
        };
      }
      return p;
    }));
  };

  const handleDeleteScene = (sceneId: string) => {
    if(window.confirm("Delete this scene?")) {
        setProjects(prev => prev.map(p => {
            if (p.id === activeProjectId) {
                return { ...p, scenes: p.scenes.filter(s => s.id !== sceneId) };
            }
            return p;
        }));
    }
  };

  // --- Rendering ---

  const renderContent = () => {
    switch (viewMode) {
      case 'HOME':
        return (
          <div className="animate-fade-in space-y-20 pb-20">
            {/* Hero Section */}
            <section className="relative h-[500px] rounded-3xl overflow-hidden flex items-center border border-cine-800 shadow-2xl">
                <img 
                    src="https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?auto=format&fit=crop&q=80&w=2056" 
                    alt="Cinema Camera" 
                    className="absolute inset-0 w-full h-full object-cover opacity-40"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-cine-950 via-cine-900/90 to-transparent" />
                
                <div className="relative z-10 px-10 md:px-20 max-w-3xl">
                    <div className="flex items-center gap-2 text-cine-accent font-mono text-sm uppercase tracking-widest mb-4">
                        <Sparkles className="w-4 h-4" /> AI-Powered Pre-Visualization
                    </div>
                    <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-6">
                        From Script to <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-cine-accent to-amber-600">Storyboard</span> in Seconds.
                    </h1>
                    <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                        Transform your screenplay into a detailed shot list and cinematic storyboard visualization automatically. Maintain character consistency and export production-ready PDFs.
                    </p>
                    <div className="flex flex-wrap gap-4">
                        <button 
                            onClick={handleNavigateProjectsList}
                            className="px-8 py-4 bg-cine-accent hover:bg-yellow-400 text-cine-900 font-bold text-lg rounded-xl shadow-lg shadow-amber-900/20 transition-all flex items-center gap-2 hover:-translate-y-1"
                        >
                            Go to Studio <ArrowRight className="w-5 h-5" />
                        </button>
                        <button 
                            onClick={handleNavigateCharacters}
                            className="px-8 py-4 bg-cine-800 hover:bg-cine-700 text-white font-bold text-lg rounded-xl border border-cine-700 transition-all flex items-center gap-2"
                        >
                            <Users className="w-5 h-5" /> Casting Library
                        </button>
                    </div>
                </div>
            </section>

            {/* Features Grid */}
            <section>
                <div className="text-center mb-12">
                    <h2 className="text-3xl font-bold text-white mb-4">Production Features</h2>
                    <p className="text-gray-400 max-w-2xl mx-auto">Everything you need to visualize your film before the cameras roll.</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Feature 1 */}
                    <div className="bg-cine-800/50 border border-cine-700 p-8 rounded-2xl hover:bg-cine-800 transition-colors group">
                        <div className="w-14 h-14 bg-cine-900 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-cine-700">
                            <Zap className="w-7 h-7 text-cine-accent" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-3">Instant Analysis</h3>
                        <p className="text-gray-400 leading-relaxed">
                            Paste your script sluglines and dialogue. Our AI breaks it down into a practical shot list with camera angles, framing, and lighting notes.
                        </p>
                    </div>

                    {/* Feature 2 */}
                    <div className="bg-cine-800/50 border border-cine-700 p-8 rounded-2xl hover:bg-cine-800 transition-colors group">
                        <div className="w-14 h-14 bg-cine-900 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-cine-700">
                            <Wand2 className="w-7 h-7 text-purple-400" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-3">Generative Visualization</h3>
                        <p className="text-gray-400 leading-relaxed">
                            Generate high-fidelity storyboards in Noir, Anime, or Realistic styles. Update shot parameters and regenerate instantly.
                        </p>
                    </div>

                    {/* Feature 3 */}
                    <div className="bg-cine-800/50 border border-cine-700 p-8 rounded-2xl hover:bg-cine-800 transition-colors group">
                        <div className="w-14 h-14 bg-cine-900 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-cine-700">
                            <FileText className="w-7 h-7 text-blue-400" />
                        </div>
                        <h3 className="text-xl font-bold text-white mb-3">Production Export</h3>
                        <p className="text-gray-400 leading-relaxed">
                            Export your entire scene to a beautifully formatted PDF storyboard, ready to print and hand to your cinematographer.
                        </p>
                    </div>
                </div>
            </section>
          </div>
        );

      case 'PROJECTS_LIST':
        return (
          <ProjectsList 
            projects={projects} 
            onOpenProject={handleOpenProject}
            onCreateProject={handleCreateProject}
            onEditProject={handleEditProject}
            onDeleteProject={handleDeleteProject}
          />
        );
      
      case 'PROJECT_DETAIL':
        if (!activeProject) return <div>Project not found</div>;
        return (
          <ProjectDetail 
            project={activeProject}
            onBack={handleNavigateProjectsList}
            onAddScene={() => setViewMode('NEW_SCENE')}
            onOpenScene={(id) => {
                setActiveSceneId(id);
                setViewMode('SCENE_DETAIL');
            }}
            onDeleteProject={handleDeleteProject}
            onDeleteScene={handleDeleteScene}
          />
        );

      case 'NEW_SCENE':
        return (
            <div className="w-full max-w-4xl mx-auto animate-fade-in py-8">
                <button 
                  onClick={() => setViewMode('PROJECT_DETAIL')}
                  className="mb-6 text-sm text-gray-400 hover:text-white flex items-center gap-1"
                >
                   <ChevronRight className="w-4 h-4 rotate-180" /> Cancel
                </button>
                <div className="text-center mb-10">
                    <h2 className="text-3xl font-bold text-white mb-2">Add New Scene</h2>
                    <p className="text-gray-400">Paste your script below to generate a shot list and storyboard.</p>
                </div>
                <ScriptForm onAnalyze={handleCreateScene} appState={analysisState} />
            </div>
        );

      case 'SCENE_DETAIL':
        if (!activeProject || !activeScene) return <div>Scene not found</div>;
        
        return (
            <Dashboard 
                scene={activeScene} 
                characters={characters}
                assets={assets}
                onBack={handleNavigateProjectDetail}
                onUpdateScene={handleUpdateScene}
            />
        );

      case 'CHARACTERS':
        return <CharacterLibrary characters={characters} setCharacters={setCharacters} />;
      
      case 'ASSETS':
        return <AssetLibrary assets={assets} setAssets={setAssets} />;
        
      default:
        return <div>Unknown View</div>;
    }
  };

  // Determine if breadcrumbs should be shown
  const showBreadcrumbs = viewMode === 'PROJECT_DETAIL' || viewMode === 'SCENE_DETAIL' || viewMode === 'NEW_SCENE';

  return (
    <div className="min-h-screen bg-cine-900 text-cine-text selection:bg-cine-accent selection:text-cine-900 flex flex-col relative font-sans">
      {/* Header */}
      <header className="border-b border-cine-800 bg-cine-900/90 backdrop-blur-md sticky top-0 z-50 shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 h-16 flex items-center justify-between">
          
          <div className="flex items-center gap-8">
              {/* Logo Area */}
              <div className="flex items-center gap-3 cursor-pointer group" onClick={handleNavigateHome}>
                <div className="p-2 bg-gradient-to-br from-cine-accent to-amber-600 rounded-lg text-cine-900 shadow-lg shadow-amber-500/20 group-hover:shadow-amber-500/40 transition-all">
                  <Clapperboard className="w-5 h-5" />
                </div>
                <h1 className="text-lg font-bold tracking-tight text-white hidden sm:block">
                  FPX <span className="text-cine-accent">ReelVision</span>
                </h1>
              </div>

              {/* Main Navigation Links */}
              <nav className="hidden md:flex items-center gap-1">
                  <button 
                    onClick={handleNavigateHome}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'HOME' ? 'text-white bg-cine-800' : 'text-gray-400 hover:text-white hover:bg-cine-800/50'}`}
                  >
                     Home
                  </button>
                  <button 
                    onClick={handleNavigateProjectsList}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${['PROJECTS_LIST', 'PROJECT_DETAIL', 'SCENE_DETAIL', 'NEW_SCENE'].includes(viewMode) ? 'text-white bg-cine-800' : 'text-gray-400 hover:text-white hover:bg-cine-800/50'}`}
                  >
                     Projects
                  </button>
                  <button 
                    onClick={handleNavigateCharacters}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'CHARACTERS' ? 'text-white bg-cine-800' : 'text-gray-400 hover:text-white hover:bg-cine-800/50'}`}
                  >
                     Characters
                  </button>
                  <button 
                    onClick={handleNavigateAssets}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${viewMode === 'ASSETS' ? 'text-white bg-cine-800' : 'text-gray-400 hover:text-white hover:bg-cine-800/50'}`}
                  >
                     Assets
                  </button>
              </nav>

              {/* Contextual Breadcrumbs */}
              {showBreadcrumbs && (
                <div className="hidden lg:flex items-center gap-2 text-sm text-gray-500 border-l border-cine-700 pl-6 h-8 animate-fade-in">
                    <button onClick={handleNavigateProjectsList} className="hover:text-white transition-colors">Projects</button>
                    
                    {activeProject && (
                        <>
                          <ChevronRight className="w-3 h-3 text-cine-700" />
                          <button 
                              onClick={handleNavigateProjectDetail}
                              className={`hover:text-white transition-colors max-w-[150px] truncate ${viewMode === 'PROJECT_DETAIL' ? 'text-white font-medium' : ''}`}
                          >
                              {activeProject.title}
                          </button>
                        </>
                    )}

                    {activeScene && viewMode === 'SCENE_DETAIL' && (
                        <>
                          <ChevronRight className="w-3 h-3 text-cine-700" />
                          <span className="text-white font-medium max-w-[200px] truncate">
                              {activeScene.title}
                          </span>
                        </>
                    )}
                </div>
              )}
          </div>

          {/* Right Actions / User */}
          <div className="flex items-center gap-4">
              {/* Mobile Nav Button could go here */}
              
              {/* User Avatar (Placeholder) */}
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cine-700 to-cine-600 border border-cine-500 flex items-center justify-center text-xs font-bold text-white cursor-pointer hover:ring-2 ring-cine-accent ring-offset-2 ring-offset-cine-900 transition-all">
                  JD
              </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow w-full max-w-[1600px] mx-auto p-4 md:p-6 lg:p-8">
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="border-t border-cine-800 py-8 mt-auto bg-cine-950">
        <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="text-sm text-gray-500">© {new Date().getFullYear()} FPX ReelVision. Transforming scripts into vision.</p>
        </div>
      </footer>

      {/* Delete Confirmation Modal */}
      {projectToDelete && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
            <div className="bg-cine-800 border border-cine-700 rounded-xl p-6 w-full max-w-sm shadow-2xl scale-100">
                <div className="flex flex-col items-center text-center">
                    <div className="w-12 h-12 bg-red-900/20 rounded-full flex items-center justify-center mb-4">
                        <AlertTriangle className="w-6 h-6 text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Delete Project?</h3>
                    <p className="text-gray-400 text-sm mb-6">
                        Are you sure you want to delete this project? This action cannot be undone.
                    </p>
                    <div className="flex gap-3 w-full">
                        <button 
                            onClick={() => setProjectToDelete(null)}
                            className="flex-1 px-4 py-2 bg-cine-700 hover:bg-cine-600 text-white rounded-lg font-medium transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={confirmDeleteProject}
                            className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-bold transition-colors shadow-lg shadow-red-900/20"
                        >
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}

export default App;